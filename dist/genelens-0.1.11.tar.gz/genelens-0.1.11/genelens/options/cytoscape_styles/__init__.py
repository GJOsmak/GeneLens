"""
Options Cytoscape_style
"""