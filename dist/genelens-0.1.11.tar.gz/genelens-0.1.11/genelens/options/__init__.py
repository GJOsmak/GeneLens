"""
Options for GeneLens
"""