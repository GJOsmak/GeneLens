"""
Example Data for Feature selection from GSE36961 
"""