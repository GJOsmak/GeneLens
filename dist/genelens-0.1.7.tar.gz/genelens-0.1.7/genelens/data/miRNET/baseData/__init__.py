"""
hsa_miRTarBase.csv = [miRNA;Target] for Homo Sapiens\n
mmu_miRTarBase.csv = [miRNA;Target] for Mus Musculus\n
mmu_String_interactome.csv = [Target;Source] - Edge list for protein-protein interaction Mus Musculus from String db\n
String_interactome.csv = [Target;Source] - Edge list for protein-protein interaction Homo Sapiens from String db\n
"""