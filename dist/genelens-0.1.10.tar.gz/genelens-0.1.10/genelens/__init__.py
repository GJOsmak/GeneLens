"""
GeneLens is a Python package for functional analysis of differentially expressed genes (DEGs) and biomarker prediction, integrating:
"""